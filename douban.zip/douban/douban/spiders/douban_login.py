# -*- coding: utf-8 -*-
import scrapy
from urllib import request
from PIL import Image

class DoubanLoginSpider(scrapy.Spider):
    name = 'douban_login'
    allowed_domains = ['douban.com']
    start_urls = ['https://accounts.douban.com/login']

    def parse(self, response):
        """实现登录"""
        self.login_after_url = "https://accounts.douban.com/login"
        self.private_url = "https://www.douban.com/people/189149354/"
        self.signature_url = 'https://www.douban.com/j/people/189149354/edit_signature'
        self.login_su_url = 'https://movie.douban.com/subject/1768645/'

        formdata = {
            'source':'movie',
            'redir':'https://movie.douban.com/subject/1768645/',
            'form_email':'2441834791@qq.com',
            'form_password':'19950826rbp',
            'remember':'movie',
            'login':'登录'
        }
        img_url = response.css('img#captcha_image::attr(src)').get()
        if img_url:
            formdata["captcha-solution"] = self.regonize_img(img_url)
            formdata["captcha-id"] = response.xpath("//input[@name='captcha-id']/@value").get()
        yield scrapy.FormRequest(url=self.login_after_url,formdata=formdata,callback=self.login_after)

    def login_after(self,response):
        if response.url == self.login_su_url:
            print("登录成功")
            #跳转到个人主页
            yield scrapy.Request(url=self.private_url,callback=self.private_page)
        else:
            print("登录失败")

    def private_page(self,respose):
        """修改签名"""
        if respose.url == self.private_url:
            print("进入了个人主页")
            ck = respose.xpath("//input[@name='ck']/@value").get()
            signature = input("输入你修改后的签名：")
            formdata = {
                "ck":ck,
                'signature':str(signature)
            }
            yield scrapy.FormRequest(url=self.signature_url,formdata=formdata)
        else:
            print("没进入个人主页")

    def regonize_img(self,url):
        """获取验证码"""
        request.urlretrieve(url,"capture.png")
        image = Image.open('capture.png')
        image.show()
        capture = input("请输入验证码：")
        return capture




