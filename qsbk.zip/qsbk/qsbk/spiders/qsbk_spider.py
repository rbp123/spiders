# -*- coding: utf-8 -*-
import scrapy
from qsbk.items import QsbkItem
from scrapy.http.response.html import HtmlResponse

class QsbkSpiderSpider(scrapy.Spider):
    name = 'qsbk_spider'
    #只有在域名下的网页才能被爬取
    allowed_domains = ['qiushibaike.com']
    start_urls = ['https://qiushibaike.com/text/page/1/']


    def parse(self, response):
        #获取所有段子div形式为selectorlist
        duanzidivs = response.xpath('//div[@id="content-left"]/div')
        self.base_domain = 'https://www.qiushibaike.com'
        for duanzi in duanzidivs:
            #形式为selector
            #获取作者get()返回第一个字符串
            author = duanzi.xpath(".//h2/text()").get().strip()
            #获取内容，getall()获取内容返回一个list
            content = duanzi.xpath(".//div[@class='content']//text()").getall()
            #join（）返回一个字符串
            content = ''.join(content).strip()
            #QsbkItem的实例化对象
            item = QsbkItem(author=author,content=content)
            #以字典的形式返回
            # duanzi = {"author":author,"content":content}
            #返回给pipeline一个item对象
            yield  item
            next_url = response.xpath('//ul[@class="pagination"]/li[last()]/a/@href').get()
            if not next_url:
                return
            else:
                yield scrapy.Request(self.base_domain + next_url,callback=self.parse)



