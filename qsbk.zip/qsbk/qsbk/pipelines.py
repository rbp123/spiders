# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html

# import json
# class QsbkPipeline(object):
#     def __init__(self):
#         self.fp = open("duanzis.json",'w',encoding='utf-8')
#     def open_spider(self,spider):
#         print("爬取开始！")
#
#     def process_item(self, item, spider):
#         item_json = json.dumps(dict(item),ensure_ascii=False)
#         self.fp.write(item_json + '\n')
#         return item
#
#     def close_spider(self,spider):
#         self.fp.close()
#         print("爬去结束！")
#         pass
import json


from scrapy.exporters import JsonItemExporter,JsonLinesItemExporter
class QsbkPipeline(object):
    def __init__(self):
        self.fp = open("duanzis.json",'wb')
        self.jsonexporter = JsonLinesItemExporter(self.fp,ensure_ascii=False,encoding='utf-8')

    def open_spider(self,spider):
        print("爬取开始！")
        # self.jsonexporter.start_exporting()

    def process_item(self, item, spider):
        # item_json = json.dumps(dict(item),ensure_ascii=False)
        # self.fp.write(item_json + '\n')
        self.jsonexporter.export_item(item)
        return item


    def close_spider(self,spider):
        # self.jsonexporter.finish_exporting()
        self.fp.close()
        print("爬取结束！")
        pass
