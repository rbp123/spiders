# -*- coding: utf-8 -*-
import scrapy
import re
import time
from fang.items import NewHouseItem,ESFHouseItem
class SfwSpider(scrapy.Spider):
    name = 'sfw'
    allowed_domains = ['esf.fang.com','newhouse.fang.com']

    start_urls = ['http://esf.fang.com/newsecond/esfcities.aspx']

    def parse(self, response):
         #获取每全部省的li
          province_lis =  response.xpath("//div[@class='outCont']//li")
          for province_li in province_lis:
              #获取每个省的a标签
              abs = province_li.xpath(".//a")
              #获取省名
              province_name = province_li.xpath(".//strong/text()").get()
              #获取每个a标签下的每一个城市的信息
              for a in abs:
                  #获取城市名
                  city_name = a.xpath(".//text()").get()
                  #剔除不是大陆的城市，待优化
                  if province_name == "其他":
                      continue
                  #直辖市特殊处理
                  if province_name == "直辖市":
                     esf_url = a.xpath(".//@href").get()#获取直辖市二手房的url
                  else:
                     esf_url = "http:" + a.xpath(".//@href").get()#获取其他城市二手房的url
                  #构造新房的url
                  esf = esf_url.split(".")
                  #北京特使处理
                  if city_name == "北京":
                     newhouse_url = 'http://newhouse.fang.com/house/s/'
                  else:
                      newhouse_url = esf[0] + ".newhouse.fang.com/house/s/"

                  yield scrapy.Request(newhouse_url,callback=self.parse_newhouse,
                                           meta={"info":(province_name,city_name)})
                  yield scrapy.Request(esf_url, callback=self.parse_esfhouse,
                                           meta={"info": (province_name, city_name)})
              #     break
              # break

    def parse_newhouse(self,response):
        province,city = response.meta.get("info")
        lis = response.xpath("//div[@class='nl_con clearfix']//li")
        for li in lis:
            if  li.xpath(".//div[@class='nlcd_name']"):
                nlcd_name = li.xpath(".//div[@class='nlcd_name']/a/text()").get().strip()
            else:
                continue
            house_type_list = li.xpath(".//div[@class='house_type clearfix']//a/text()").getall()
            house_type_list = list(map(lambda x:re.sub("\s"," ",x),house_type_list))
            rooms = list(filter(lambda x:x.endswith("居"),house_type_list))
            area = li.xpath(".//div[@class='house_type clearfix']//text()").getall()[-1]
            area = re.sub(r"\s|－","",area)
            district_text = "".join(li.xpath(".//div[@class='address']/a//text()").getall())
            if nlcd_name == "中冶兴隆新城·红石郡":
                continue
            else:
                district = re.search(r".*\[(.+)\].*",district_text).group(1)
            address = li.xpath(".//div[@class='address']/a/@title").get()
            sale = li.xpath(".//div[contains(@class,'fangyuan')]/span/text()").get()
            price = "".join(li.xpath(".//div[@class='nhouse_price']//text()").getall()).strip()
            price = re.sub(r"广告","",price).strip()
            origin_url = li.xpath(".//div[@class='nlcd_name']//a/@href").get()
            if origin_url == "http://adshow.fang.com/release/clickredirect?z=fang&la=0&si=1&cg=0&c=13042&ci=116988&or=0&" \
                            "l=0&bg=0&b=1176966&u=https://668603.fang.com/":
                origin_url = li.xpath(".//div[@class='nlcd_name']//a/@href").get()
            else:
                origin_url = "http:" + li.xpath(".//div[@class='nlcd_name']//a/@href").get()
            yield NewHouseItem(province=province,city=city,name=nlcd_name,rooms=rooms,area=area,
                               origin_url=origin_url,sale=sale,district=district,address=address,price=price)
        next_url = response.xpath("//div[@class='page']//a[@class='next']/@href").get()
        if next_url:
            yield scrapy.Request(url=response.urljoin(next_url),callback=self.parse_newhouse,meta={"info":(province,city)},dont_filter=True)

    def parse_esfhouse(self,response):
        province,city = response.meta.get("info")
        dls = response.xpath("//div[@class='shop_list shop_list_4']/dl")
        for dl in dls:
            item = ESFHouseItem(province=province,city=city)
            item["name"] = dl.xpath(".//span[@class='tit_shop']/text()").get()
            infos = dl.xpath(".//p[@class='tel_shop']//text()").getall()
            infos = list(map(lambda x:re.sub(r"\s","",x),infos))
            for info in infos:
                if "厅" in info:
                    item["rooms"] = info
                elif "." in  info:
                    item["area"] = info
                elif "层"in info:
                    item["floor"] = info
                elif "向" in info:
                    item["toward"] = info
                elif "年" in info:
                    item["year"] = info.replace("年建","")
            address = dl.xpath(".//p[@class='add_shop']//span[1]/text()").get()
            item["address"] = address
            price = "".join(dl.xpath(".//dd[@class='price_right']//span[1]//text()").getall())
            item["price"] = price
            unit = dl.xpath(".//dd[@class='price_right']//span[2]/text()").get()
            item["unit"] = unit
            yield item
            next_url = response.urljoin(response.xpath("//div[@class='page_al']//p[1]/a/@href").get())
            if next_url:
                yield scrapy.Request(url=next_url,callback=self.parse_esfhouse,meta={"info":(province,city)},dont_filter=True)
