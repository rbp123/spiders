from scrapy import cmdline
cmdline.execute("scrapy crawl car_spider".split())