# -*- coding: utf-8 -*-
import scrapy


class RenrenSpiderSpider(scrapy.Spider):
    name = 'renren_spider'
    allowed_domains = ['renren.com']
    start_urls = ['http://renren.com/']

    def start_requests(self):
        login_url = "https://www.douban.com/accounts/login"
        data = {"form_email":"2441834791@qq.com",
                "form_password":"19950826rbp"}
        request = scrapy.FormRequest(url=login_url,formdata=data,callback=self.parse_page)
        yield request
    def parse_page(self,response):
        with open("renren.html",'w',encoding='utf-8') as fp:
            fp.write(response.text)

