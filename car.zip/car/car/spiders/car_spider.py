# -*- coding: utf-8 -*-
import scrapy
from car.items import CarItem


class CarSpiderSpider(scrapy.Spider):
    name = 'car_spider'
    allowed_domains = ['autohome.com.cn']
    start_urls = ['https://car.autohome.com.cn/photolist/series/65/p1/?pvareaid=101196']

    def parse(self, response):
        divs = response.xpath("//div[@id]//ul[@id='imgList']")
        for div in divs:
            titles = div.xpath(".//li//a/text()").get()
            if not div.xpath(".//li/a/img/@src2"):
                urls = div.xpath(".//li/a/img/@src").getall()
            else:
                urls = div.xpath(".//li/a/img/@src2").getall()
            urls = list(map(lambda url:response.urljoin(url),urls))
            item = CarItem(title=titles,urls=urls)
            yield item




