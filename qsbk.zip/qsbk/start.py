from scrapy import  cmdline
cmdline.execute("scrapy crawl qsbk_spider".split())