import os
path = os.path.join(os.path.dirname(os.path.dirname(__file__)),'images')
print(os.path.join(os.path.dirname(os.path.dirname(__file__)),'images'))
if not os.path.exists(path):
    os.mkdir(path)
else:
    print("文件存在")


