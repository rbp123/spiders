from scrapy import cmdline
cmdline.execute("scarpy crawl wxapp_spider".split())